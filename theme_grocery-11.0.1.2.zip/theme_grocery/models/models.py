# -*- coding: utf-8 -*-

import json

from odoo import models, fields, api


class website(models.Model):
    _inherit = 'website'

    def get_categories(self):
        categories = self.env['product.public.category'].sudo().search([])
        return categories

    def get_homepage_categories(self):
        categories = self.env['homepage.categories'].sudo().search([], order='sequence')
        return categories.mapped('category_id')

    def get_homepage_sliders(self):
        sliders = self.env['homepage.slider'].sudo().search([], order='sequence')
        return sliders

    def get_homepage_horizontal_banner(self):
        banners = self.env['homepage.horizontal.banner'].sudo().search([], order='sequence')
        return banners

    def get_testimonials(self):
        testimonials = self.env['customer.testimonial'].sudo().search([], order='sequence')
        return testimonials

    def get_bestseller_products(self):
        products = self.env['bestseller.product'].sudo().search([], order='sequence')
        return products.mapped('product_tmpl_id')

    def get_featured_products(self):
        products = self.env['featured.product'].sudo().search([], order='sequence')
        return products.mapped('product_tmpl_id')

    def get_latest_products(self):
        products = self.env['latest.product'].sudo().search([], order='sequence')
        return products.mapped('product_tmpl_id')

    def get_latest_blog_posts(self):
        blog_posts = self.env['blog.post'].sudo().search(
            [('website_published', '=', True)], order='id DESC')
        return blog_posts

    def get_cover_image(self, blog_post):
        return json.loads(blog_post.cover_properties).get('background-image')[4:-1]

    def get_product_avg_rating(self, product):
        if product.rating_ids:
            total_rating = product.rating_ids.mapped('rating')
            return sum(total_rating) / len(product.rating_ids)
        else:
            return 0


class HomepageCategories(models.Model):
    _name = 'homepage.categories'
    _rec_name = 'category_id'
    _order = 'sequence'

    category_id = fields.Many2one('product.public.category', string='Category')
    sequence = fields.Integer('Sequence', default=10)


class HomepageSlider(models.Model):
    _name = 'homepage.slider'
    _order = 'sequence'

    name = fields.Char('Name')
    image = fields.Binary('Slider Image', help="Slider image size must be 938px x 437px.")
    link = fields.Char('Link')
    sequence = fields.Integer('Sequence', default=10)


class HomepageHorizontalBanner(models.Model):
    _name = 'homepage.horizontal.banner'
    _order = 'sequence'

    name = fields.Char('Name (Label)')
    sub_heading = fields.Char('Sub Heading')
    image = fields.Binary('Background Image', help='Image size must be 358px x 275px.')
    link = fields.Char('Link')
    sequence = fields.Integer('Sequence', default=10)


class BestsellerProduct(models.Model):
    _name = 'bestseller.product'
    _order = 'sequence'

    product_tmpl_id = fields.Many2one('product.template', string='Product')
    sequence = fields.Integer('Sequence', default=10)


class CustomerTestimonial(models.Model):
    _name = 'customer.testimonial'
    _order = 'sequence'

    name = fields.Char('Customer Name', required=True)
    image = fields.Binary('Customer Photo')
    review = fields.Text('Review', required=True)
    sequence = fields.Integer('Sequence', default=10)


class FeaturedProduct(models.Model):
    _name = 'featured.product'
    _order = 'sequence'

    product_tmpl_id = fields.Many2one('product.template', string='Product')
    sequence = fields.Integer('Sequence', default=10)


class LatestProduct(models.Model):
    _name = 'latest.product'
    _order = 'sequence'

    product_tmpl_id = fields.Many2one('product.template', string='Product')
    sequence = fields.Integer('Sequence', default=10)
