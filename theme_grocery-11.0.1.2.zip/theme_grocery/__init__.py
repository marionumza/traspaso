# -*- coding: utf-8 -*-

from . import controllers
from . import models
from odoo.api import Environment, SUPERUSER_ID


def uninstall_hook(cr, registry):
    env = Environment(cr, SUPERUSER_ID, {})
    wishlist_view_id = env['ir.ui.view'].search([
        ('key', '=', 'theme_grocery.wishlist_link'),
    ])
    if wishlist_view_id:
        wishlist_view_id.unlink()

    search_count_view_id = env['ir.ui.view'].search([
        ('key', '=', 'website_sale.search count'),
        ('active', '=', False)
    ])
    if search_count_view_id:
        search_count_view_id.unlink()

    view_id = env['ir.ui.view'].search([
        ('key', '=', 'theme_grocery.website_glossary_header'),
    ])
    if view_id:
        view_id.unlink()

    add_to_cart_id = env['ir.ui.view'].search([
        ('key', '=', 'website_sale.products_add_to_cart'),
    ])
    if add_to_cart_id:
        add_to_cart_id.unlink()

    this_module_id = env['ir.module.module'].search([('name', '=', 'theme_grocery')])
    this_module_id.write({'state': 'uninstalled'})

    module_id = env['ir.module.module'].search([('name', '=', 'website_sale')])
    module_id.button_immediate_upgrade()
    return True
