odoo.define('theme_grocery.script', function (require) {
    "use strict";

    require('web.dom_ready');
    var core = require('web.core');
    var ajax = require('web.ajax');
    var _t = core._t;

    $(".home-slider .owl-carousel").owlCarousel({
        items:1,
        autoplay: true,
        loop: true,
        nav : true, 
        dots: true,
        autoplaySpeed : 500,
        navSpeed : 500,
        dotsSpeed : 500,
        autoplayHoverPause: true,
        margin:1,
    });
    $(".best-seller .owl-carousel").owlCarousel({
        loop: false,
        nav: false,
        dots: true,
        autoplay: false,
        autoplayHoverPause: true,
        margin: 30,
        responsive: {0: {items: 1}, 480: {items: 1}, 768: {items: 1}, 991: {items: 1}, 1200: {items: 1}}
    });
    $(".review-slider .owl-carousel").owlCarousel({
        loop: true,
        nav: false,
        dots: true,
        autoplay: 1500,
        autoplayHoverPause: true,
        margin: 30,
        responsive: {0: {items: 1}, 480: {items: 1}, 768: {items: 1}, 991: {items: 1}, 1200: {items: 1}}
    });
    $("#featured .owl-carousel, #latest .owl-carousel, #bestseller .owl-carousel").owlCarousel({
        loop: true,
        nav: false,
        dots: true,
        autoplay: 3000,
        autoplayHoverPause: true,
        margin: 15,
        responsive: {0: {items: 1}, 420: {items: 2}, 768: {items: 3}, 991: {items: 3}, 1200: {items: 4}}
    });
    $(".homepage-blogs .owl-carousel").owlCarousel({
        loop: true,
        nav: false,
        dots: true,
        autoplay: false,
        autoplayHoverPause: true,
        margin: 15,
        responsive: {0: {items: 1}, 480: {items: 2}, 768: {items: 2}, 991: {items: 3}, 1200: {items: 3}}
    });

    // Product hover show few button
    $("#products_grid .oe_product").mouseenter(function(){
        $(this).find(".hover-button").css({"display": "block"});
        $(this).find(".oe_product_image").css({"opacity": "0.2","transition": "1s"});
        $(this).find(".hover-button").addClass("hover-btn-anim");
    });
    $("#products_grid .oe_product").mouseleave(function(){
        $(this).find(".hover-button").css({"display": "none"});
        $(this).find(".oe_product_image").css({"opacity": "1", "transition": "1s"});
        $(this).find(".hover-button").removeClass("hover-btn-anim").css({"transition": "2s"});
    });

    // Shop category hide/show
    $('#products_grid_before').on('click', '.fa-angle-right.open_close_sub_category',function(){
        $(this).removeClass('fa-angle-right').addClass('fa-angle-down');
        $(this).parents('li').find('ul:first').show('slow');
    });
    $('#products_grid_before').on('click', '.fa-angle-down.open_close_sub_category',function(){
        $(this).removeClass('fa-angle-down').addClass('fa-angle-right');
        $(this).parent().find('ul:first').hide('slow');
    });

    // Toogle view filter component
    $('.view-apply-filter').click(function(){
        $(".filter_view").slideToggle('slow');
    });

    $('.open-filter').click(function(){
        if ($("#products_grid_before").hasClass('hidden-xs'))
            $("#products_grid_before").removeClass('hidden-xs').style({'display': 'none'});
        $("#products_grid_before").slideToggle('slow');
    });

    // Remove filter attribute value
    $(".att-remove-btn").click(function(){
        var value = $(this).attr("data-att-val-id");
        if(value){
            $("form.js_attributes input[value="+value+"]").removeAttr("checked");
            $("form.js_attributes input").closest("form").submit();
        }
    });

    // Product page rating
    // var $star_rating = $('.star-rating .fa');
    var SetRatingStar = function() {
        $('.star-rating').each(function(){
            var $star_rating = $(this).find('.fa');
            return $star_rating.each(function() {
                var avg = $star_rating.parent().find('input.rating-value').val() || '0';
                if (parseInt(avg) >= parseInt($(this).data('rating'))) {
                    return $(this).removeClass('fa-star-o').addClass('fa-star');
                } else {
                    return $(this).removeClass('fa-star').addClass('fa-star-o');
                }
            });
        });
    };
    SetRatingStar();

    $("#main_menu").mCustomScrollbar({
        axis:"x", // horizontal scrollbar
        theme:"dark"
    });


    $('.oe_website_sale').each(function () {
        var oe_website_sale = this;

        $(oe_website_sale).on("change", ".oe_cart input.js_quantity[data-product-id]", function () {
            setTimeout(myTimer, 1500);

            function myTimer() {
                ajax.jsonRpc("/shop/cart/get_cart_amount", 'call', {
                }).then(function (data) {
                    $(".price-minicart .price").html(data.cart_amount).hide().fadeIn(600);
                    if ('cart_qty' in data)
                        $("#my_cart").html(data.cart_qty).hide().fadeIn(600);
                });
            }
        });

        $(oe_website_sale).on("click", ".o_wish_add", function () {
            setTimeout(myTimer, 1500);

            function myTimer() {
                ajax.jsonRpc("/shop/cart/get_cart_amount", 'call', {
                }).then(function (data) {
                    $(".price-minicart .price").html(data.cart_amount).hide().fadeIn(600);
                    if ('cart_qty' in data)
                        $("#my_cart").html(data.cart_qty).hide().fadeIn(600);
                });
            }
        });

    });

});
